#!/bin/sh
# Agent2API 本地网关 · OpenMinis 内置插件安装脚本
# 上游：github.com/aimod-cc/Agent2API v3.0.8 (MIT)
# 本脚本纯离线，不联网、不调用 apt、不需要 Node —— 上游是自包含 Rust 二进制。
set -eu

PAYLOAD="${A2A_PLUGIN_PAYLOAD:?缺少 A2A_PLUGIN_PAYLOAD}"
TOOL_DIR="${A2A_TOOL_DIR:?缺少 A2A_TOOL_DIR}"
TOOL_DATA="${A2A_TOOL_DATA:-/var/minis/shared/builtin-plugins/a2a/data}"

printf '=== Agent2API 本地网关 安装开始 ===\n'
printf '工具目录: %s\n' "$TOOL_DIR"

# 1. 基本检查：payload 必须带二进制与面板
test -f "$PAYLOAD/bin/agent2api-server" || {
    printf '错误：payload 缺少 bin/agent2api-server\n' >&2; exit 1
}
test -f "$PAYLOAD/ui/index.html" || {
    printf '错误：payload 缺少 ui/index.html\n' >&2; exit 1
}

# 2. 部署运行集（原子替换）
STAGING="$TOOL_DIR/.staging"
rm -rf "$STAGING"
mkdir -p "$STAGING/bin" "$STAGING/ui"
cp -f "$PAYLOAD/bin/agent2api-server" "$STAGING/bin/agent2api-server"
cp -a "$PAYLOAD/ui/." "$STAGING/ui/"
test -f "$STAGING/ui/index.html" || { printf '错误：部署后缺 ui/index.html\n' >&2; exit 1; }

mkdir -p "$TOOL_DIR"
rm -rf "$TOOL_DIR/bin" "$TOOL_DIR/ui"
mv "$STAGING/bin" "$TOOL_DIR/bin"
mv "$STAGING/ui" "$TOOL_DIR/ui"
rmdir "$STAGING" 2>/dev/null || true
chmod 755 "$TOOL_DIR/bin/agent2api-server"

# 3. 数据目录
mkdir -p "$TOOL_DATA"
printf '数据目录 -> %s\n' "$TOOL_DATA"

# 4. 安装命令入口 a2a-gateway（宿主用 nohup 后台拉起；本入口前台阻塞，勿加 &）
cat > "$TOOL_DIR/bin/a2a-gateway" <<'GATEWAY'
#!/bin/sh
# Agent2API 网关启动入口 —— 由宿主调用（前台运行，勿加 &）。
# ★ 上游二进制不解析任何命令行参数：连 --help 都会直接绑定端口启动服务。
# 因此 --version / --help 必须在这里拦截消化，绝不透传给二进制。
set -eu
TOOL_DIR="$(cd "$(dirname "$0")/.." && pwd)"
DATA_DIR="${A2A_DATA_DIR:-/var/minis/shared/builtin-plugins/a2a/data}"
PORT="${A2A_PORT:-18901}"

case "${1:-}" in
  --version|-v) printf '3.0.8\n'; exit 0 ;;
  --help|-h)
    printf 'Agent2API gateway launcher (foreground)\n'
    printf 'env: A2A_PORT (default %s), A2A_DATA_DIR (default %s)\n' "$PORT" "$DATA_DIR"
    exit 0
    ;;
esac

mkdir -p "$DATA_DIR"
export AGENT2API_HOST=127.0.0.1
export AGENT2API_PROXY_PORT="$PORT"
export AGENT2API_PROXY_HOME="$DATA_DIR"
export AGENT2API_UI_DIR="$TOOL_DIR/ui"
export AGENT2API_ALLOW_NO_KEY=1
exec "$TOOL_DIR/bin/agent2api-server"
GATEWAY
chmod 755 "$TOOL_DIR/bin/a2a-gateway"

# 5. 安装后自检（只验证文件，绝不运行二进制 —— 对该二进制而言运行即启动服务）
test -x "$TOOL_DIR/bin/agent2api-server" || { printf '错误：二进制不可执行\n' >&2; exit 1; }
test -x "$TOOL_DIR/bin/a2a-gateway" || { printf '错误：命令入口未创建\n' >&2; exit 1; }
test -f "$TOOL_DIR/ui/index.html" || { printf '错误：面板文件缺失\n' >&2; exit 1; }

printf '=== 安装完成 ===\n'
printf '网关地址: http://127.0.0.1:%s/v1\n' "${A2A_PORT:-18901}"
printf '管理面板: http://127.0.0.1:%s/\n' "${A2A_PORT:-18901}"
printf '在插件市场卡片点击「启动网关」即可运行。\n'
