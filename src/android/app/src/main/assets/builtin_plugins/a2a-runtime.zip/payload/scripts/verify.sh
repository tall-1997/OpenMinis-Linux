#!/bin/sh
# Agent2API 网关 · 安装后验证脚本（由 BuiltinPluginInstaller.verifyCommand 调用）
#
# ★★★ 极重要：本脚本 stdout 的【首行】会被宿主当作 installedVersion 存库 ★★★
# isUpdateNewer 用它判断是否「可更新」；首行若不是纯版本号，数字回退逻辑会
# 误判成「可更新」。因此：★首行必须是纯版本号，且不得含其它数字★，
# 其余信息一律走 stderr。
#
# 注意：绝不运行 agent2api-server —— 该二进制不解析参数，运行即绑定端口
# 启动服务（上游 --help 亦是如此），验证脚本只做文件级检查。
set -eu

TOOL_DIR="${A2A_TOOL_DIR:?缺少 A2A_TOOL_DIR}"

# ↓ 这一行是版本号，必须保持为输出到 stdout 的第一行
printf '3.0.8\n'

# ↓ 其余所有信息走 stderr，绝不污染首行
log() { printf '%s\n' "$*" >&2; }

log '验证 1/3：网关二进制'
test -x "$TOOL_DIR/bin/agent2api-server" || { log '失败：缺少可执行二进制 agent2api-server'; exit 1; }
log '  ok'

log '验证 2/3：管理面板'
test -f "$TOOL_DIR/ui/index.html" || { log '失败：缺少 ui/index.html'; exit 1; }
log '  ok'

log '验证 3/3：启动入口'
test -x "$TOOL_DIR/bin/a2a-gateway" || { log '失败：缺少启动入口 a2a-gateway'; exit 1; }
log '  ok'

log '验证通过：Agent2API 网关已就绪，在插件市场卡片可启动服务'
