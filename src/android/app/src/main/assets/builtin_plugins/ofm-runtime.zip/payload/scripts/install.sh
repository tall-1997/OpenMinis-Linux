#!/bin/sh
# Our Free Model 免费模型网关 · OpenMinis 内置插件安装脚本
# 上游：github.com/Ebony-Vinyl/dsh-our-free-model v2.3.0 (MIT)
# 本脚本纯离线，不联网、不调用 apt。
set -eu

PAYLOAD="${OFM_PLUGIN_PAYLOAD:?缺少 OFM_PLUGIN_PAYLOAD}"
TOOL_DIR="${OFM_TOOL_DIR:?缺少 OFM_TOOL_DIR}"
RUNTIME_SRC="$PAYLOAD/runtime"

printf '=== 免费模型网关 安装开始 ===\n'
printf '工具目录: %s\n' "$TOOL_DIR"

# 1. 基本检查
test -f "$RUNTIME_SRC/packages/standalone/cli.mjs" || {
    printf '错误：payload 缺少 runtime/packages/standalone/cli.mjs\n' >&2; exit 1
}
if ! command -v node >/dev/null 2>&1; then
    printf '错误：未找到 node。请通过宿主开发套件提供 Node.js 22+\n' >&2
    exit 1
fi
printf 'node: %s\n' "$(node --version)"

# 2. 部署运行集（原子替换）
STAGING="$TOOL_DIR/.runtime.staging"
rm -rf "$STAGING"
mkdir -p "$STAGING"
cp -a "$RUNTIME_SRC/." "$STAGING/"

# 校验关键文件
test -f "$STAGING/packages/standalone/cli.mjs" || { printf '错误：部署后缺 cli.mjs\n' >&2; exit 1; }
test -f "$STAGING/packages/standalone/service.mjs" || { printf '错误：部署后缺 service.mjs\n' >&2; exit 1; }
test -f "$STAGING/src/core/runtime.js" || { printf '错误：部署后缺 src/core/runtime.js\n' >&2; exit 1; }

rm -rf "$TOOL_DIR/runtime"
mv "$STAGING" "$TOOL_DIR/runtime"

# 3. 数据目录
TOOL_DATA="${OFM_TOOL_DATA:-/var/minis/shared/builtin-plugins/ofm/data}"
mkdir -p "$TOOL_DATA"
printf '数据目录 -> %s\n' "$TOOL_DATA"

# 4. 安装命令入口 ofm-gateway（宿主用它启动服务）
mkdir -p "$TOOL_DIR/bin"
cat > "$TOOL_DIR/bin/ofm-gateway" <<'GATEWAY'
#!/bin/sh
# 免费模型网关启动入口 —— 由宿主调用（前台运行，勿加 &）
# 宿主通过 servicePort 轮询端口判定就绪，因此这里必须前台阻塞。
set -eu
TOOL_DIR="$(cd "$(dirname "$0")/.." && pwd)"
RUNTIME="$TOOL_DIR/runtime"
DATA_DIR="${OFM_DATA_DIR:-/var/minis/shared/builtin-plugins/ofm/data}"
PORT="${OFM_PORT:-18900}"

# 版本探测：宿主默认 verifyCmd 是 "<link> --version"，其 stdout 首行会被
# 当作 installedVersion 存库。这里显式输出纯版本号，避免退化成「可更新」误报。
case "${1:-}" in
  --version|-v) printf '2.3.0\n'; exit 0 ;;
esac

# ============================================================================
# ★ Node 版本锁定（关键）★
# 运行集内嵌 undici（packages/standalone/channels/business.mjs），其 webidl 层调用
# worker_threads.markAsUncloneable —— 该 API 仅 Node 22+ 提供。
# 若被 Node 18 拉起，会报：webidl.util.markAsUncloneable is not a function
# 系统里可能同时存在多个 node（/usr/bin/node 常为旧版，/usr/local/bin/node 较新），
# PATH 顺序不可靠，因此这里显式按版本挑选，绝不盲目用 `node`。
# ============================================================================
pick_node() {
  # 1) 显式覆盖优先
  if [ -n "${OFM_NODE:-}" ] && [ -x "$OFM_NODE" ]; then
    if node_major "$OFM_NODE" 2>/dev/null | grep -qE '^(2[2-9]|[3-9][0-9])$'; then
      printf '%s' "$OFM_NODE"; return 0
    fi
  fi
  # 2) 按候选列表找第一个主版本 >= 22 的
  for c in \
      /usr/local/bin/node \
      /root/.local/bin/node \
      /usr/bin/node \
      /bin/node
  do
    [ -x "$c" ] || continue
    m=$(node_major "$c" 2>/dev/null) || continue
    case "$m" in
      ''|*[!0-9]*) continue ;;
    esac
    if [ "$m" -ge 22 ] 2>/dev/null; then printf '%s' "$c"; return 0; fi
  done
  # 3) 兜底：PATH 里的 node，若版本够也可用
  if command -v node >/dev/null 2>&1; then
    m=$(node_major "$(command -v node)" 2>/dev/null) || m=0
    if [ "${m:-0}" -ge 22 ] 2>/dev/null; then printf '%s' "$(command -v node)"; return 0; fi
  fi
  return 1
}

node_major() {
  "$1" --version 2>/dev/null | sed 's/^v//' | cut -d. -f1
}

NODE_BIN="$(pick_node)" || NODE_BIN=""
if [ -z "$NODE_BIN" ]; then
  DETECTED="$(command -v node 2>/dev/null || echo 无)"
  DETECTED_VER=""
  [ "$DETECTED" != "无" ] && DETECTED_VER="$(node --version 2>/dev/null)"
  echo "启动失败：需要 Node.js 22 或更高版本（运行集内嵌 undici 依赖 worker_threads.markAsUncloneable，该 API 自 Node 22 起提供）。" >&2
  echo "检测到的 node：${DETECTED} ${DETECTED_VER}" >&2
  echo "请升级 Node，或设置环境变量 OFM_NODE 指向 Node 22+ 的可执行文件。" >&2
  exit 1
fi

# 默认无鉴权，调用方无需 API Key
export OFM_REQUIRE_KEY="${OFM_REQUIRE_KEY:-0}"
export OFM_PORT="$PORT"
mkdir -p "$DATA_DIR"

# 透传参数：宿主/自检可能传 --help 等，必须原样转发，
# 否则会被当成无参调用而真的启动服务并前台阻塞（曾导致安装卡死）。
exec "$NODE_BIN" "$RUNTIME/packages/standalone/cli.mjs" "$@" --port "$PORT" --data-dir "$DATA_DIR"
GATEWAY
chmod 755 "$TOOL_DIR/bin/ofm-gateway"

# 5. 管理脚本（供终端手动启停）
cp -f "$PAYLOAD/scripts/ofm-control.sh" "$TOOL_DIR/bin/ofmctl" 2>/dev/null || true
chmod 755 "$TOOL_DIR/bin/ofmctl" 2>/dev/null || true

# 6. 安装后自检（不启动服务，只验证可执行 + 模块可加载）
test -x "$TOOL_DIR/bin/ofm-gateway" || { printf '错误：命令入口未创建\n' >&2; exit 1; }
# --help 会立即返回；加超时兜底，避免任何分支误进入前台服务模式
if command -v timeout >/dev/null 2>&1; then
    timeout 30 "$TOOL_DIR/bin/ofm-gateway" --help >/dev/null 2>&1 || true
else
    "$TOOL_DIR/bin/ofm-gateway" --help >/dev/null 2>&1 &
    _probe=$!; sleep 8; kill "$_probe" 2>/dev/null || true
fi

printf '=== 安装完成 ===\n'
printf '网关地址: http://127.0.0.1:%s/v1\n' "${OFM_PORT:-18900}"
printf '在「工具详情页」点击「启动网关」即可运行；可开「随应用自启动」。\n'
