# Our Free Model 免费模型网关 · OpenMinis 内置插件版

上游项目：github.com/Ebony-Vinyl/dsh-our-free-model v2.3.0（MIT License）
本插件取上游 packages/standalone 独立服务，降维为本地 OpenAI 兼容网关。

## 内置移植改动
1. `src/forward.js` 的 `authorized()` 新增 `noAuthMode()`：默认关闭 API Key 校验
   （服务仅监听 127.0.0.1，本机自用）。设 `OFM_REQUIRE_KEY=1` 恢复原校验。
2. `packages/standalone/management.mjs` 的会话校验同步默认放行。

## 接口
- `POST /v1/chat/completions`（OpenAI 兼容，支持 stream）
- `POST /v1/responses`
- `GET  /v1/models`
- `GET  /health`

## 裁剪说明
未收录：DSH 插件壳（index.js/client.js）、packages/desktop（Tauri 桌面壳）、
worker（Cloudflare 变体）、docs/.github/scripts、vendor 下 158 个 .ts 源码存档
（Node 运行时不加载）。运行集 126 文件，与上游完整版行为一致（已实测）。
