#!/bin/sh
# 免费模型网关 · 手动管理脚本（装到 $TOOL_DIR/bin/ofmctl）
# 宿主 UI 的「启动网关 / 停止网关」已能覆盖日常使用，本脚本供终端手动操作。
set -eu

TOOL_DIR="$(cd "$(dirname "$0")/.." && pwd)"
PORT="${OFM_PORT:-18900}"
DATA_DIR="${OFM_DATA_DIR:-/var/minis/shared/builtin-plugins/ofm/data}"
BASE="http://127.0.0.1:$PORT"

running() { curl -s -o /dev/null --max-time 4 "$BASE/v1/models" 2>/dev/null; }

case "${1:-status}" in
  start)
    if running; then echo "✔ 已在运行：$BASE/v1"; exit 0; fi
    echo "提示：推荐直接使用工具详情页的「启动网关」按钮（由宿主托管进程）。"
    echo "终端启动可执行：nohup $TOOL_DIR/bin/ofm-gateway >/tmp/ofm.log 2>&1 &"
    ;;
  status)
    if running; then
      echo "状态: ✔ 运行中  $BASE/v1"
      n=$(curl -s --max-time 20 "$BASE/v1/models" | node -e 'let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{try{console.log((JSON.parse(d).data||[]).length)}catch(e){console.log("?")}})')
      echo "在线模型: $n 个"
    else
      echo "状态: ✘ 未运行（请在工具详情页点「启动网关」）"
    fi
    ;;
  models)
    curl -s --max-time 25 "$BASE/v1/models" | node -e 'let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{try{(JSON.parse(d).data||[]).forEach(m=>console.log(m.id))}catch(e){console.log(d.slice(0,500))}})'
    ;;
  *)
    cat <<EOF
ofmctl —— 免费模型网关手动管理

  ofmctl status    查看状态与在线模型数
  ofmctl models    列出可用模型
  ofmctl start     启动提示（推荐用宿主 UI 按钮）

地址：$BASE/v1   （免 API Key）
数据：$DATA_DIR
EOF
    ;;
esac
