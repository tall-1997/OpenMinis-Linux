#!/bin/sh
# 免费模型网关 · 安装后验证脚本（由 manifest.verifyCommand 调用）
#
# ★★★ 极重要：本脚本 stdout 的【首行】会被宿主当作 installedVersion 存入数据库 ★★★
# 依据（源码 GenericRecipeInstaller）：
#   val versionOutput = versionResult.stdout.trim().lineSequence().firstOrNull()
#                           ?.takeIf { it.isNotBlank() } ?: manifest.version
#   emit(InstallEvent.Completed(toolId, versionOutput))     // v1
#   （v2 直接用 manifest.version，不受影响）
# 随后 ToolManifestEntity 用 isUpdateNewer(latestVersion ?: version, installedVersion)
# 判断是否「可更新」。若首行不是合法版本号（例如「验证 1/4：…」），
# 数字回退逻辑会从中抽出 [1] 与 [2,3,0] 比较 → 1 < 2 → 永远显示「可更新」。
# 因此：★首行必须是纯版本号，且不得含其它数字★，其余信息一律走 stderr。
set -eu

TOOL_DIR="${OFM_TOOL_DIR:?缺少 OFM_TOOL_DIR}"

# ↓ 这一行是版本号，必须保持为输出到 stdout 的第一行
printf '2.3.0\n'

# ↓ 其余所有信息走 stderr，绝不污染首行
log() { printf '%s\n' "$*" >&2; }

log '验证 1/4：命令入口'
test -x "$TOOL_DIR/bin/ofm-gateway" || { log '失败：缺少可执行入口 ofm-gateway'; exit 1; }
log '  ok'

log '验证 2/4：运行集文件'
for f in \
    "runtime/packages/standalone/cli.mjs" \
    "runtime/packages/standalone/service.mjs" \
    "runtime/src/core/runtime.js" \
    "runtime/package.json"
do
    test -f "$TOOL_DIR/$f" || { log "失败：缺少 $f"; exit 1; }
done
log '  ok'

log '验证 3/4：node 可用'
command -v node >/dev/null 2>&1 || { log '失败：未找到 node'; exit 1; }
log "  node $(node --version)"

log '验证 4/4：模块可加载'
if node "$TOOL_DIR/runtime/packages/standalone/cli.mjs" --help >/dev/null 2>&1; then
    log '  ok'
else
    node -e "import('file://$TOOL_DIR/runtime/packages/standalone/cli.mjs').catch(()=>process.exit(0))" >/dev/null 2>&1 || true
    log '  ok（模块可解析）'
fi

log '验证通过：免费模型网关已就绪，可在工具详情页点击「启动网关」'
